async function loadProducts() {
  const res = await fetch("http://localhost:3000/health")
  const data = await res.json()
  document.getElementById("products").innerHTML =
    "<p>API Status: " + data.status + "</p>"
}
loadProducts()