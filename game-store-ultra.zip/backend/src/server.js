require("dotenv").config()
const express = require("express")
const http = require("http")
const { Server } = require("socket.io")

const app = express()
app.use(express.json())

app.get("/health", (_, res) => {
  res.json({ status: "OK PRODUCTION" })
})

const server = http.createServer(app)
const io = new Server(server, { cors: { origin: "*" } })

io.on("connection", socket => {
  console.log("Client connected")
})

server.listen(3000, () => {
  console.log("API running on 3000")
})