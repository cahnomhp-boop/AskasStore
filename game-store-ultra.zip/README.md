# Game Store Ultra

## Run Backend
cd backend
npm install
npm start

## Frontend
Open frontend/index.html in browser.